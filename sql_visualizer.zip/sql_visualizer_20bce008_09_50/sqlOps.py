from Relation import Relation as re
import mysql.connector
import cx_Oracle
import streamlit as st
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="1111",
    database="mydatabase"
)

my_cursor = mydb.cursor()
# con = cx_Oracle.connect('aky/akshay2110@localhost')

# my_cursor = con.cursor()

class Queries:

    @staticmethod
    def __options():
        print("1. NATURAL JOIN")
        print("2. INNER JOIN")
        print("3. OUTER LEFT JOIN")
        print("4. OUTER RIGHT JOIN")
        c = int(input('choose any option: '))
        return c

    def join(self):
        choice = self.__options()
        s = input("SELECT ")
        SELECT = "SELECT " + s
        f = input("FROM ")
        FROM = " FROM " + f
        if choice == 1:
            table1 = input('NATURAL JOIN ')
            table = ' NATURAL JOIN ' + table1
            que1 = input('WHERE ')
            que = ' WHERE ' + que1
            sy = ' ⋈ '
        elif choice == 2:
            table1 = input('INNER JOIN ')
            table = ' INNER JOIN ' + table1
            que1 = input('ON ')
            que = ' ON ' + que1
            sy = ' θ '
        elif choice == 3:
            table1 = input('OUTER LEFT JOIN ')
            table = ' LEFT JOIN ' + table1
            que1 = input('ON ')
            que = ' ON ' + que1
            sy = ' ⟕ '
        elif choice == 4:
            table1 = input('OUTER RIGHT JOIN ')
            table = ' OUTER RIGHT JOIN ' + table1
            que1 = input('ON ')
            que = ' ON ' + que1
            sy = '  ⟖ '
        else:
            print('INVALID CHOICE')
            return None

        query = SELECT + FROM + table + que
        print("\nConverting into Relation Algebra:\n ")
        r = re()
        que1 = que1.replace('and', '^')
        que1 = que1.replace('or', 'v')
        if 0 < choice < 5:
            r.show(s)
            que1 = que1.lower()
            print('( ','σ ', que1,end=" ) ")
            print('( ',f,sy, table1,' ) ')
        my_cursor.execute(query)
        row = my_cursor.fetchall()
        re.display(s, s)
        re.dis_row(row)

    @staticmethod
    def select(inp1,inp2,inp3):
        SELECT = inp1
        FROM = inp2
        WHERE = inp3
        print("\nConverting into Relation Algebra:\n ")
        cols = re.ret_all_cols(my_cursor, FROM)
        sel = SELECT

        # select logic
        if SELECT == '*':
            sel = cols
        r = re()
        r.show(sel)

        # where logic
        if len(WHERE) != 0:
            re.show_wh(WHERE)

        # from logic
        re.show_f(FROM)

        string = re.str_exe(SELECT, FROM, WHERE)
        my_cursor.execute(string)
        row = my_cursor.fetchall()
        re.display(SELECT, sel)
        re.dis_row(row)
        
    def create_table(inp,inp2):
        # input = inp.split()
        str = 'CREATE TABLE ' + inp + ' '
        # for i in range(1,len(input),2):
        #     str = str + ' (' +input[i] + input[i+1] + ','
        # str = str + ')'
        str = str + '(' + inp2 + ')'
        print(str)
        my_cursor.execute(str)
        
    def exct_other(other):
        my_cursor.execute(other)
        my_result = my_cursor.fetchall()
        # st.write(str(my_result))
        
    def update(inp1, inp2, inp3):
        updt = 'UPDATE ' + inp1 + ' SET ' + inp2 + ' WHERE ' + inp3 
        print(updt)
        my_cursor.execute(updt)
        
        