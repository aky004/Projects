import display as d
from sqlOps import Queries

qu = Queries()
while True:
    ch = d.dis()
    if ch == 1:
        qu.join()
    elif ch == 2:
        Queries.select()
    elif ch == 3:
        exit()
    else:
        print("Invalid input")
