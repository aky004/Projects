import streamlit as st
class Relation:
    @staticmethod
    def show_col(query):
        for i in query:
            if i == query[-1]:
                print(i, end=' ')
            else:
                print(i, ",", end=' ')

    def show(self, se):
        sel = str(se)
        s = sel.split(",")
        print('( Π ', end=' ')
        self.show_col(s)
        print(")", end=' ')

    @staticmethod
    def show_f(fr):
        print(" ( ",fr," ) ", end='')

    @staticmethod
    def ret_all_cols(my_cursor, fr):
        ex = "show columns from " + fr
        my_cursor.execute(ex)
        colms = my_cursor.fetchall()
        ret = []
        for colm in colms:
            ret.append(colm[0])
        return ret

    @staticmethod
    def show_wh(whe):
        w1 = whe.split(" ")
        print('σ ', end='')
        print(" ( ", end='')
        for op in w1:
            if op.lower() == 'and':
                print(" ^ ", end="")
            elif op.lower() == 'or':
                print(" v ", end="")
            else:
                print(op, end=" ")

        print(" ) ", end=' ')

    @staticmethod
    def show_wh_join(table, qu):
        print("( ", end=" ")
        if 'natural join' in table.lower():
            print(' ⋈ ', end=" ")
        if 'right join' in table.lower():
            print(' ⟕ ', end=" ")
        if 'left join' in table.lower():
            print(' ⟖ ', end=' ')
        if 'inner join' in table.lower():
            print(' θ ', end=' ')
        t = table.split(' ')
        print(t[-1], end=" ")
        q = qu.split(" ")
        for op in q:
            if op.lower() == 'and':
                print(" ^ ", end="")
            elif op.lower() == 'or':
                print(" v ", end="")
            else:
                print(op, end=" ")
        print(" ) \n\n")

    @staticmethod
    def display(sel, data):
        i = 1
        prstr = ""
        if sel != '*':
            data = sel.split(',')
            for col in data:
                i += 20
                prstr = prstr + str("{:^18s}".format(col)) + ' | '
        else:
            for col in data:
                i += 20
                prstr = prstr + str("{:^18s}".format(col)) + ' | '
        st.write(prstr)
        prstr=""
        for _ in range(i):
            prstr = prstr + str("-") + " "
        st.write(prstr)
        prstr=""

    @staticmethod
    def dis_row(data):
        prstr = ''
        for tb in data:
            for k in tb:
                m = str(k)
                prstr += str("{:^18s}".format(m)) + ' | '
            st.write(prstr)
            prstr=""

    @staticmethod
    def str_exe(sel, fr, wh):
        if len(wh) > 0:
            string = "SELECT " + sel + " FROM " + fr + " WHERE " + wh
        else:
            string = "SELECT " + sel + " FROM " + fr
        print("\n--------------------------------------------")
        print("OUT-PUT OF QUERY")
        print("--------------------------------------------\n")
        return string
