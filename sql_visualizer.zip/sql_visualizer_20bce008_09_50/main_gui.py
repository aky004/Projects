from string import whitespace
from regex import P
import streamlit as st
import re
import numpy as np
from tkinter import VERTICAL
import sqlOps
from streamlit_option_menu import option_menu   
# import display as d

st.set_page_config(layout="wide")

# with open("E:\\College\\Documents\\OS\\Innovative\\styles.css") as f:
#     st.markdown('<style>{}</style>'.format(f.read()), unsafe_allow_html=True)

heading = "<div class='title'>STRUCTURED QUERY LANGUAGE VISUALIZER</heading1>"
st.markdown(heading, unsafe_allow_html=True)

  
line = "<hr class='line'>"
st.markdown(line, unsafe_allow_html=True)

col1, col2 = st.columns([3, 9])
with col1:
    choice = option_menu("", ["CREATE", "ALTER",
                         "UPDATE", "SELECT","JOIN","DROP","OTHER"], orientation=VERTICAL)
    if choice == "CREATE":
        with col2:
            st.write("Create Table")
            inp = st.text_input("Enter Table Name to create : ")
            inp2 = st.text_input("Enter Table attributes : ")
            if inp2!="" and inp!="" :
                try :
                    sqlOps.Queries.create_table(inp,inp2)
                    st.write("Table created successfully")
                except :
                    st.write("Error")
            else :
                st.write("Fill the both Field")        

    elif choice == "ALTER":
        with col2:
            st.write("Alter any table")
            alter = st.text_input("Enter your sql here: ")
            try :
                sqlOps.Queries.exct_other(alter)
                st.write("Success")
            except :
                st.write("Error")
    elif choice == "UPDATE":
        with col2:
            st.write("Update Table (Modify changes to rows)")
            inp1 = st.text_input("Table name to update : ")
            inp2 = st.text_input("Set new values : ")
            inp3 = st.text_input("Where condition : ")
            if(inp1 != "" or inp2 != "" or inp3 != ""):
                try :
                    sqlOps.Queries.update(inp1, inp2, inp3)
                    st.write("Successfully updated")
                except :
                    st.write("Error")
            else:
                st.write("Fill all field")

    elif choice == "SELECT":
        with col2:
            # st.write("Select column(s) to display")
            inp1 = st.text_input("Select columns : ")
            inp2 = st.text_input("Select Table : ")
            inp3 = st.text_input("Select Condition : ")
            try :
                sqlOps.Queries.select(inp1, inp2, inp3)
            except :
                st.write("Error")

    elif choice == "JOIN":
        with col2:
            st.write("Join 2 tables")

    elif choice == "DROP":
        with col2:
            st.write("Remove any table")
            remove = st.text_input("Enter Table name to remove or querry to remove other elements: ")
            try :
                sqlOps.Queries.exct_other(remove)
                st.write("Success")
            except :
                st.write("Error")
                
    elif choice == "OTHER":
        with col2:
            st.write("Other type of querry then menue")
            other = st.text_input("Enter your sql/plsql here: ")
            try :
                sqlOps.Queries.exct_other(other)
                st.write("Success")
            except :
                st.write("Error")
    else:
        with col2:
            st.write("sql")
            sql_to_ra = st.text_input("SQL Statement : ")
