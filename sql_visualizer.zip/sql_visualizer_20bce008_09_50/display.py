def dis():
    print(" ")
    print(" ")
    print("-----------------------------------------")
    print("SQL TO RELATIONAL ALGEBRA QUERY CONVERTER")
    print("-----------------------------------------")
    print(" ")

    print("NOTE: This converter will only convert select-from where  statements without sub-queries")

    print(" ")
    print("1. join queries")
    print("2. select from queries")
    print("3. close the program")
    c = int(input("choose any option: "))
    return c

