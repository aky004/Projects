import cv2
# import cv
import os

for root, subdirs, files in os.walk('./'):
    for f in files:
        if f.endswith('jpg'):
            # print(f)
            img = cv2.imread('./' + f)
            img = cv2.resize(img, (640, 480))
            cv2.imwrite('./'+f, img)
            print(*["Image", f, "is resized to 640 X 480"])